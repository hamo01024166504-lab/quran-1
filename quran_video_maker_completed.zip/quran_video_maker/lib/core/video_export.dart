import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'audio.dart';
import 'quran.dart';
import 'store.dart';

class VideoPreset {
  const VideoPreset(this.label, this.width, this.height, this.fps, this.crf);
  final String label;
  final int width;
  final int height;
  final int fps;
  final int crf;
  String get size => '${width}x$height';
}

const videoPresets = <VideoPreset>[
  VideoPreset('عمودي 1080p · Shorts / Reels / TikTok', 1080, 1920, 30, 27),
  VideoPreset('عمودي 720p · أخف على الهاتف', 720, 1280, 25, 28),
  VideoPreset('عمودي 540p · حجم أصغر', 540, 960, 24, 29),
  VideoPreset('أفقي 1080p · YouTube', 1920, 1080, 30, 27),
  VideoPreset('أفقي 720p', 1280, 720, 25, 28),
  VideoPreset('Instagram Feed 4:5', 1080, 1350, 30, 27),
  VideoPreset('مربع 1080p', 1080, 1080, 30, 27),
];

class VideoExportService {
  static Future<void> cancel() async => FFmpegKit.cancel();

  static Future<void> export({
    required Store store,
    required AudioData audio,
    required List<Ayah> ayat,
    required int fromVerse,
    required int toVerse,
    required int startMs,
    required int endMs,
    required File? background,
    required List<File> sceneBackgrounds,
    required bool mixScenes,
    required VideoPreset preset,
    required String fontName,
    required double fontSize,
    required int textArgb,
    required bool allahGold,
    required bool showEnglish,
    required bool glow,
    required void Function(double) onProgress,
    required void Function(String) onStatus,
  }) async {
    if (ayat.isEmpty) throw Exception('لا توجد آيات للتصدير.');
    if (!audio.mp3.existsSync() || audio.mp3.lengthSync() == 0) throw Exception('ملف التلاوة غير موجود أو فارغ. أعد تحميل الصوت.');
    if (endMs <= startMs) throw Exception('مدة التصدير غير صحيحة. أعد اختيار الآيات وتحميل التلاوة.');
    if (background != null && (!background.existsSync() || background.lengthSync() == 0)) throw Exception('ملف الخلفية غير موجود أو فارغ.');

    final hasAccess = await Gal.requestAccess(toAlbum: true);
    if (!hasAccess) throw Exception('لم يتم منح إذن حفظ الفيديو في المعرض. اسمح للتطبيق بحفظ الوسائط ثم أعد المحاولة.');

    final temp = await getTemporaryDirectory();
    final id = DateTime.now().microsecondsSinceEpoch;
    final assFile = File('${temp.path}/quran_$id.ass');
    final output = File('${temp.path}/quran_video_$id.mp4');
    final durationMs = endMs - startMs;
    final durationSec = durationMs / 1000;
    await assFile.writeAsString(_ass(ayat, audio.timings, fromVerse, toVerse, startMs, endMs,
        preset, fontName, fontSize, textArgb, allahGold, showEnglish, glow), flush: true);

    final fontsDir = store.dir('fonts').path;
    final subtitleFilter = "subtitles=filename='${_filterPath(assFile.path)}':fontsdir='${_filterPath(fontsDir)}'";
    final filter = 'scale=${preset.width}:${preset.height}:force_original_aspect_ratio=increase,'
        'crop=${preset.width}:${preset.height},fps=${preset.fps},$subtitleFilter';
    final startSeconds = (startMs / 1000).toStringAsFixed(3);
    final duration = durationSec.toStringAsFixed(3);
    final String command;
    final selectedScenes = mixScenes ? sceneBackgrounds : const <File>[];
    final sceneCount = durationSec >= 4 && selectedScenes.length > 1
        ? max(2, (durationSec / 5).ceil()).toInt()
        : 0;
    if (sceneCount > 1) {
      final pool = List<File>.from(selectedScenes)..shuffle(Random(id));
      final ordered = <File>[];
      while (ordered.length < sceneCount) {
        if (ordered.isNotEmpty) {
          pool.shuffle(Random(id + ordered.length));
          if (pool.length > 1 && pool.first.path == ordered.last.path) {
            final swap = pool[0];
            pool[0] = pool[1];
            pool[1] = swap;
          }
        }
        ordered.addAll(pool.take(sceneCount - ordered.length));
      }
      final inputs = StringBuffer();
      final graph = StringBuffer();
      for (var i = 0; i < ordered.length; i++) {
        final f = ordered[i];
        if (_isImage(f.path)) {
          inputs.write('-loop 1 -framerate ${preset.fps} -i ${_quote(f.path)} ');
        } else {
          inputs.write('-stream_loop -1 -i ${_quote(f.path)} ');
        }
        final rawSegment = i == ordered.length - 1
            ? durationSec - (durationSec / ordered.length) * i
            : durationSec / ordered.length;
        final segment = max(.1, rawSegment).toStringAsFixed(3);
        graph.write('[$i:v]scale=${preset.width}:${preset.height}:force_original_aspect_ratio=increase,'
            'crop=${preset.width}:${preset.height},fps=${preset.fps},trim=duration=$segment,setpts=PTS-STARTPTS[v$i];');
      }
      for (var i = 0; i < ordered.length; i++) { graph.write('[v$i]'); }
      graph.write('concat=n=${ordered.length}:v=1:a=0[base];[base]$subtitleFilter[vout]');
      final audioInput = ordered.length;
      inputs.write('-ss $startSeconds -i ${_quote(audio.mp3.path)} ');
      command = '-y $inputs-t $duration -filter_complex "${graph.toString()}" '
          '-map "[vout]" -map $audioInput:a:0 -c:v libx264 -preset ultrafast '
          '-crf ${preset.crf} -pix_fmt yuv420p -c:a aac -b:a 128k '
          '-movflags +faststart -shortest ${_quote(output.path)}';
    } else if (background == null) {
      command = '-y -f lavfi -i "color=c=0x0B1020:s=${preset.size}:r=${preset.fps}:d=$duration" '
          '-ss $startSeconds -i ${_quote(audio.mp3.path)} -t $duration '
          '-vf "${filter.replaceAll('"', r'\"')}" -map 0:v:0 -map 1:a:0 '
          '-c:v libx264 -preset ultrafast -crf ${preset.crf} -pix_fmt yuv420p '
          '-c:a aac -b:a 128k -movflags +faststart -shortest ${_quote(output.path)}';
    } else if (_isImage(background.path)) {
      command = '-y -loop 1 -framerate ${preset.fps} -i ${_quote(background.path)} '
          '-ss $startSeconds -i ${_quote(audio.mp3.path)} -t $duration '
          '-vf "${filter.replaceAll('"', r'\"')}" -map 0:v:0 -map 1:a:0 '
          '-c:v libx264 -preset ultrafast -crf ${preset.crf} -pix_fmt yuv420p '
          '-c:a aac -b:a 128k -movflags +faststart -shortest ${_quote(output.path)}';
    } else {
      command = '-y -stream_loop -1 -i ${_quote(background.path)} '
          '-ss $startSeconds -i ${_quote(audio.mp3.path)} -t $duration '
          '-vf "${filter.replaceAll('"', r'\"')}" -map 0:v:0 -map 1:a:0 '
          '-c:v libx264 -preset ultrafast -crf ${preset.crf} -pix_fmt yuv420p '
          '-c:a aac -b:a 128k -movflags +faststart -shortest ${_quote(output.path)}';
    }

    onStatus('جاري تجهيز الفيديو…');
    final done = Completer<void>();
    Object? failure;
    var encoded = false;
    var saved = false;
    await FFmpegKit.executeAsync(command, (session) async {
      try {
        final code = await session.getReturnCode();
        if (ReturnCode.isSuccess(code)) {
          if (!output.existsSync() || output.lengthSync() < 2048) {
            throw Exception('انتهى التصدير لكن ملف MP4 الناتج غير صالح أو فارغ.');
          }
          encoded = true;
          onProgress(1);
          onStatus('تم إنشاء الفيديو، جاري حفظه في المعرض…');
          await Gal.putVideo(output.path, album: 'Quran Video Maker');
          saved = true;
        } else {
          final logs = (await session.getOutput()) ?? '';
          failure = Exception('فشل محرك الفيديو (رمز ${code?.getValue() ?? 'غير معروف'}). ${_shortError(logs)}');
        }
      } catch (e) {
        failure = e;
      } finally {
        if (!done.isCompleted) done.complete();
      }
    }, null, (statistics) {
      final ms = statistics.getTime();
      if (ms > 0) onProgress(min(.98, ms / durationMs).toDouble());
    });

    try {
      await done.future.timeout(Duration(seconds: max(180, (durationSec * 8).round()).toInt()), onTimeout: () {
        FFmpegKit.cancel();
        throw TimeoutException('استغرق التصدير وقتًا أطول من المتوقع. جرّب دقة 540p أو مقطعًا أقصر.');
      });
    } finally {
      if (assFile.existsSync()) await assFile.delete();
      // Keep the MP4 in cache only until it has been copied to the public gallery.
      if (output.existsSync() && (saved || !encoded)) await output.delete();
    }
    if (failure != null) {
      if (encoded && !saved) throw Exception('$failure الملف المؤقت موجود في: ${output.path}');
      throw failure!;
    }
  }

  static String _ass(List<Ayah> ayat, List<Timing> timings, int from, int to,
      int startMs, int endMs, VideoPreset preset, String fontName, double fontSize,
      int textArgb, bool allahGold, bool showEnglish, bool glow) {
    final scale = preset.width / 1080.0;
    final arabicSize = max(28, (fontSize * scale * 1.45).round());
    final englishSize = max(18, (arabicSize * .34).round());
    final primary = _assColor(textArgb);
    final outline = glow ? 2 : 1;
    final shadow = glow ? 1 : 0;
    final safeFont = _fontFamily(fontName);
    final b = StringBuffer()
      ..writeln('[Script Info]')
      ..writeln('ScriptType: v4.00+')
      ..writeln('WrapStyle: 2')
      ..writeln('ScaledBorderAndShadow: yes')
      ..writeln('PlayResX: ${preset.width}')
      ..writeln('PlayResY: ${preset.height}')
      ..writeln('\n[V4+ Styles]')
      ..writeln('Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding')
      ..writeln('Style: Default,$safeFont,$arabicSize,$primary,&H00FFFFFF,&H99000000,&H64000000,0,0,0,0,100,100,0,0,1,$outline,$shadow,5,55,55,100,1')
      ..writeln('\n[Events]')
      ..writeln('Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text');

    final byVerse = <int, Timing>{for (final t in timings) t.verse: t};
    for (final a in ayat.where((x) => x.n >= from && x.n <= to)) {
      final t = byVerse[a.n];
      if (t == null) continue;
      final fromLocal = max(0, t.from - startMs).toInt();
      final toLocal = min(endMs - startMs, max(fromLocal + 100, t.to - startMs)).toInt();
      if (toLocal <= fromLocal) continue;
      final words = a.words.map((w) {
        final value = _assText(w.ar);
        if (allahGold && w.isAllah) return '{\\c&H0042C5F5&}$value{\\c}';
        return value;
      }).join(' ');
      final arabic = '$words  ﴿${_arabicDigits(a.n)}﴾';
      final translation = showEnglish && a.english.trim().isNotEmpty
          ? '\\N{\\fs$englishSize\\c&H00E8E8E8&}${_assText(a.english)}'
          : '';
      b.writeln('Dialogue: 0,${_assTime(fromLocal)},${_assTime(toLocal)},Default,,0,0,0,,$arabic$translation');
    }
    return b.toString();
  }

  static String _fontFamily(String name) {
    if (name.toLowerCase().contains('amiriquran')) return 'Amiri Quran';
    if (name.toLowerCase().contains('scheherazade')) return 'Scheherazade New';
    if (name.toLowerCase().contains('amiri')) return 'Amiri';
    if (name.toLowerCase().contains('lateef')) return 'Lateef';
    return name.replaceAll(',', '').replaceAll('\n', ' ').trim();
  }

  static String _assTime(int ms) {
    final cs = (ms / 10).floor();
    final h = cs ~/ 360000;
    final m = (cs ~/ 6000) % 60;
    final s = (cs ~/ 100) % 60;
    final c = cs % 100;
    return '$h:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}.${c.toString().padLeft(2, '0')}';
  }

  static String _assColor(int argb) {
    final r = (argb >> 16) & 0xff, g = (argb >> 8) & 0xff, b = argb & 0xff;
    return '&H00${b.toRadixString(16).padLeft(2, '0').toUpperCase()}${g.toRadixString(16).padLeft(2, '0').toUpperCase()}${r.toRadixString(16).padLeft(2, '0').toUpperCase()}';
  }

  static String _arabicDigits(int n) {
    const d = '٠١٢٣٤٥٦٧٨٩';
    return n.toString().split('').map((x) => d[int.parse(x)]).join();
  }

  static String _assText(String s) => s
      .replaceAll(RegExp(r'<[^>]*>'), '')
      .replaceAll('{', r'\{')
      .replaceAll('}', r'\}')
      .replaceAll('\r', ' ')
      .replaceAll('\n', ' ')
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'");

  static String _quote(String s) => '"${s.replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"';
  static String _filterPath(String s) => s.replaceAll('\\', r'\\').replaceAll(':', r'\:').replaceAll("'", r"\'").replaceAll(',', r'\,').replaceAll('[', r'\[').replaceAll(']', r'\]');
  static bool _isImage(String path) => RegExp(r'\.(png|jpe?g|webp|bmp)$', caseSensitive: false).hasMatch(path);
  static String _shortError(String s) {
    final cleaned = s.trim().split('\n').where((x) => x.trim().isNotEmpty).toList();
    if (cleaned.isEmpty) return 'تحقق من الخلفية والصوت والخطوط ثم أعد المحاولة.';
    final message = cleaned.take(3).join(' ');
    return message.substring(0, min(260, message.length).toInt());
  }
}
