import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'net.dart';
import 'store.dart';

const _gf = 'https://github.com/google/fonts/raw/main/ofl';
const fontUrls = {
  'AmiriQuran-Regular.ttf': '$_gf/amiriquran/AmiriQuran-Regular.ttf',
  'Amiri-Regular.ttf': '$_gf/amiri/Amiri-Regular.ttf',
  'ScheherazadeNew-Regular.ttf': '$_gf/scheherazadenew/ScheherazadeNew-Regular.ttf',
  'Lateef-Regular.ttf': '$_gf/lateef/Lateef-Regular.ttf',
};

class Job {
  Job(this.label, this.run, {this.essential = false});
  final String label;
  final bool essential;
  final Future<void> Function(void Function(double)) run;
  double progress = 0;
  String status = 'waiting';
  String? error;
}

/// First launch downloads only the small chapter list and optional fonts.
/// Quran text and audio are downloaded lazily when the user selects them.
class SetupController extends ChangeNotifier {
  SetupController(this.store) {
    jobs.addAll([
      Job('الخطوط العربية (اختياري)', _fonts),
      Job('قائمة السور', _chapters, essential: true),
    ]);
  }

  final Store store;
  final jobs = <Job>[];
  bool running = false;

  bool get allDone => jobs.every((j) => j.status == 'done');
  bool get essentialDone => jobs.where((j) => j.essential).every((j) => j.status == 'done');
  double get total => jobs.isEmpty ? 0 : jobs.map((j) => j.progress).reduce((a, b) => a + b) / jobs.length;

  Future<void> start() async {
    if (running) return;
    running = true;
    notifyListeners();
    for (final j in jobs) {
      if (j.status == 'done') continue;
      j.status = 'running';
      j.error = null;
      notifyListeners();
      try {
        await j.run((p) {
          j.progress = p.clamp(0, 1).toDouble();
          notifyListeners();
        });
        j.progress = 1;
        j.status = 'done';
      } catch (e) {
        j.status = 'failed';
        j.error = _friendlyError(e);
      }
      notifyListeners();
    }
    running = false;
    notifyListeners();
  }

  String _friendlyError(Object e) {
    final s = e.toString();
    if (s.contains('SocketException') || s.contains('Failed host lookup')) return 'لا يوجد اتصال بالإنترنت. افحص الاتصال ثم أعد المحاولة.';
    if (s.contains('HTTP 401') || s.contains('HTTP 403')) return 'رفض مصدر البيانات الطلب (صلاحية أو مفتاح API).';
    return s.length > 220 ? '${s.substring(0, 220)}…' : s;
  }

  Future<void> _fonts(void Function(double) p) async {
    var i = 0;
    var successes = 0;
    for (final e in fontUrls.entries) {
      try {
        await download(e.value, store.file('fonts/${e.key}'));
        successes++;
      } catch (_) {}
      p(++i / fontUrls.length);
    }
    // System fonts remain a usable fallback; fonts are not essential.
    if (successes == 0) throw Exception('تعذر تنزيل الخطوط الإضافية. يمكنك المتابعة بخط النظام أو إضافته لاحقًا.');
  }

  Future<void> _chapters(void Function(double) p) async {
    final f = store.file('chapters.json');
    if (f.existsSync() && f.lengthSync() > 0) {
      p(1);
      return;
    }
    final j = await getJson('https://api.quran.com/api/v4/chapters?language=ar');
    final list = (j['chapters'] as List)
        .map((c) => {'id': c['id'], 'ar': c['name_arabic'], 'en': c['name_simple'], 'v': c['verses_count']})
        .toList();
    if (list.length != 114) throw Exception('لم تكتمل قائمة السور من مصدر البيانات.');
    await f.writeAsString(jsonEncode(list));
    p(1);
  }
}
