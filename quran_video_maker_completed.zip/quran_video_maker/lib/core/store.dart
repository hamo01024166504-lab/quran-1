import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Store {
  Store(this.root, this.prefs);
  final Directory root;
  final SharedPreferences prefs;

  static Future<Store> open() async => Store(
      await getApplicationSupportDirectory(), await SharedPreferences.getInstance());

  bool get setupDone => prefs.getBool('setup_done') ?? false;
  set setupDone(bool v) => prefs.setBool('setup_done', v);

  String get pexelsKey {
    final k = prefs.getString('pexels_key');
    return (k != null && k.isNotEmpty)
        ? k
        : const String.fromEnvironment('PEXELS_KEY');
  }

  set pexelsKey(String v) => prefs.setString('pexels_key', v.trim());

  Directory dir(String name) {
    final d = Directory('${root.path}/$name');
    if (!d.existsSync()) d.createSync(recursive: true);
    return d;
  }

  File file(String rel) {
    final f = File('${root.path}/$rel');
    f.parent.createSync(recursive: true);
    return f;
  }

  List<File> backgrounds() => dir('bg')
      .listSync()
      .whereType<File>()
      .where((f) => RegExp(r'\.(mp4|mov|m4v|png|jpe?g|webp|bmp)$', caseSensitive: false).hasMatch(f.path))
      .toList();

  /// يسجّل كل الخطوط المحمّلة (TTF/OTF) ويرجّع أسماءها.
  Future<List<String>> loadFonts() async {
    final names = <String>[];
    for (final e in dir('fonts').listSync()) {
      if (e is! File) continue;
      final low = e.path.toLowerCase();
      if (!low.endsWith('.ttf') && !low.endsWith('.otf')) continue;
      final name = e.uri.pathSegments.last
          .replaceAll(RegExp(r'\.(ttf|otf)$', caseSensitive: false), '');
      final bytes = await e.readAsBytes();
      final loader = FontLoader(name)
        ..addFont(Future.value(ByteData.sublistView(bytes)));
      await loader.load();
      names.add(name);
    }
    return names;
  }
}
