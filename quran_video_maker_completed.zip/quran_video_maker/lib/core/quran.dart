import 'dart:convert';
import 'dart:io';
import 'store.dart';
import 'net.dart';

class Word {
  Word(this.pos, this.ar, this.en);
  final int pos;
  final String ar;
  final String en;
  static final _marks = RegExp(r'[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]');
  bool get isAllah {
    final n = ar.replaceAll(_marks, '').replaceAll('ٱ', 'ا');
    return n.contains('الله') || n.contains('لله');
  }
}

class Ayah {
  Ayah(this.n, this.words, {this.translation = ''});
  final int n;
  final List<Word> words;
  final String translation;
  String get arabic => words.map((w) => w.ar).join(' ');
  String get english => translation.isNotEmpty ? translation : words.map((w) => w.en).where((s) => s.isNotEmpty).join(' ');
}

class Chapter {
  Chapter(this.id, this.ar, this.en, this.verses);
  final int id;
  final String ar;
  final String en;
  final int verses;
}

class QuranRepo {
  QuranRepo(this.store);
  final Store store;

  List<Chapter> chapters() {
    final f = store.file('chapters.json');
    if (!f.existsSync()) throw Exception('قائمة السور غير جاهزة. افحص الإنترنت وأعد فتح البرنامج.');
    final l = jsonDecode(f.readAsStringSync()) as List;
    return l.map((c) => Chapter(c['id'], c['ar'], c['en'], c['v'])).toList();
  }

  List<Ayah> ayat(int ch) {
    final f = store.file('quran/$ch.json');
    if (!f.existsSync() || f.lengthSync() == 0) return [];
    return _decodeAyat(jsonDecode(f.readAsStringSync()) as List);
  }

  Future<List<Ayah>> ensureAyat(int ch) async {
    final f = store.file('quran/$ch.json');
    if (f.existsSync() && f.lengthSync() > 0) {
      try {
        final cached = jsonDecode(f.readAsStringSync()) as List;
        if (cached.isNotEmpty && (cached.first as Map).containsKey('t')) return _decodeAyat(cached);
      } catch (_) {}
      // Old/corrupt cache without verse-level translations: rebuild it.
      try { await f.delete(); } catch (_) {}
    }
    final verses = <Map<String, dynamic>>[];
    var page = 1;
    while (true) {
      final j = await getJson('https://api.quran.com/api/v4/verses/by_chapter/$ch'
          '?language=en&words=true&word_fields=text_uthmani&word_translation_language=en'
          '&translations=131&per_page=50&page=$page');
      final rows = j['verses'] as List?;
      if (rows == null || rows.isEmpty) break;
      for (final raw in rows) {
        final v = Map<String, dynamic>.from(raw as Map);
        final translations = (v['translations'] as List?) ?? const [];
        var translation = translations.isNotEmpty ? '${translations.first['text'] ?? ''}' : '';
        translation = translation.replaceAll(RegExp(r'<[^>]*>'), '').replaceAll('&quot;', '"').replaceAll('&#39;', "'").replaceAll('&amp;', '&');
        verses.add({
          'n': v['verse_number'],
          't': translation,
          'w': (v['words'] as List? ?? const [])
              .where((w) => w['char_type_name'] == 'word')
              .map((w) => {'p': w['position'], 'a': w['text_uthmani'], 'e': (w['translation']?['text'] ?? '')})
              .toList(),
        });
      }
      final next = j['pagination']?['next_page'];
      if (next == null) break;
      page = next as int;
    }
    if (verses.isEmpty) throw Exception('لم يرجع مصدر القرآن أي آيات للسورة $ch.');
    // Atomic-ish write: do not leave a partial JSON file after a network failure.
    final tmp = File('${f.path}.part');
    await tmp.writeAsString(jsonEncode(verses), flush: true);
    if (f.existsSync()) await f.delete();
    await tmp.rename(f.path);
    return _decodeAyat(verses);
  }

  List<Ayah> _decodeAyat(List l) => l.map((v) => Ayah(
    v['n'] as int,
    ((v['w'] as List?) ?? const []).map((w) => Word(w['p'] as int, '${w['a'] ?? ''}', '${w['e'] ?? ''}')).toList(),
    translation: '${v['t'] ?? ''}',
  )).toList();
}

