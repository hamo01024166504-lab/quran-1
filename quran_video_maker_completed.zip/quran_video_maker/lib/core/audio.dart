import 'dart:convert';
import 'dart:io';
import 'net.dart';
import 'store.dart';

class Reciter {
  const Reciter(this.id, this.name);
  final int id;
  final String name;
}

/// معرّفات التلاوات في Quran.com API (تلاوات متاحة عبر الـAPI الرسمي).
const reciters = [
  Reciter(7, 'مشاري العفاسي'),
  Reciter(2, 'عبد الباسط عبد الصمد'),
  Reciter(6, 'محمود خليل الحصري'),
  Reciter(9, 'محمد صديق المنشاوي'),
  Reciter(3, 'عبد الرحمن السديس'),
  Reciter(10, 'سعود الشريم'),
];

class Timing {
  Timing(this.verse, this.from, this.to, this.segs);
  final int verse;
  final int from; // ms من بداية ملف السورة
  final int to;
  final List<List<int>> segs; // [رقم الكلمة, بداية ms, نهاية ms]
}

class AudioData {
  AudioData(this.mp3, this.timings);
  final File mp3;
  final List<Timing> timings;
}

class AudioService {
  static Future<AudioData> ensure(Store s, int rid, int ch,
      {void Function(double)? onProgress}) async {
    final jf = s.file('audio/$rid/$ch.json');
    final mf = s.file('audio/$rid/$ch.mp3');
    Map<String, dynamic> meta;
    if (!jf.existsSync() || !mf.existsSync()) {
      final j = await getJson(
          'https://api.quran.com/api/v4/chapter_recitations/$rid/$ch?segments=true');
      meta = Map<String, dynamic>.from(j['audio_file']);
      var url = meta['audio_url'] as String;
      if (!url.startsWith('http')) url = 'https://verses.quran.com/$url';
      await download(url, mf, onProgress: onProgress);
      await jf.writeAsString(jsonEncode(meta));
    } else {
      meta = jsonDecode(await jf.readAsString());
    }
    final ts = (meta['timestamps'] as List).map((t) {
      final verse = int.parse((t['verse_key'] as String).split(':')[1]);
      final segs = ((t['segments'] ?? []) as List)
          .map<List<int>>(
              (x) => [for (final v in (x as List).take(3)) (v as num).toInt()])
          .where((x) => x.length == 3)
          .toList();
      return Timing(verse, (t['timestamp_from'] as num).toInt(),
          (t['timestamp_to'] as num).toInt(), segs);
    }).toList();
    return AudioData(mf, ts);
  }
}
