import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

Future<dynamic> getJson(String url, {Map<String, String>? headers}) async {
  Object? err;
  for (var i = 0; i < 3; i++) {
    try {
      final r = await http
          .get(Uri.parse(url), headers: headers)
          .timeout(const Duration(seconds: 30));
      if (r.statusCode == 200) return jsonDecode(utf8.decode(r.bodyBytes));
      err = 'HTTP ${r.statusCode}';
    } catch (e) {
      err = e;
    }
    await Future.delayed(Duration(seconds: 1 + i));
  }
  throw Exception('$url → $err');
}

/// تحميل ملف (يتخطى لو موجود). بيكتب في ملف مؤقت وبعدين يعيد التسمية.
Future<void> download(String url, File f,
    {void Function(double)? onProgress}) async {
  if (f.existsSync() && f.lengthSync() > 0) {
    onProgress?.call(1);
    return;
  }
  final client = http.Client();
  final tmp = File('${f.path}.part');
  IOSink? sink;
  try {
    final res = await client
        .send(http.Request('GET', Uri.parse(url)))
        .timeout(const Duration(seconds: 45));
    if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');
    sink = tmp.openWrite();
    var got = 0;
    final total = res.contentLength ?? 0;
    await for (final chunk in res.stream.timeout(const Duration(seconds: 45))) {
      sink.add(chunk);
      got += chunk.length;
      if (total > 0) onProgress?.call(got / total);
    }
    await sink.flush();
    await sink.close();
    sink = null;
    if (!tmp.existsSync() || tmp.lengthSync() == 0) throw Exception('الملف الذي تم تنزيله فارغ');
    if (f.existsSync()) await f.delete();
    await tmp.rename(f.path);
    onProgress?.call(1);
  } catch (_) {
    if (sink != null) {
      try { await sink.close(); } catch (_) {}
    }
    if (tmp.existsSync()) {
      try { await tmp.delete(); } catch (_) {}
    }
    rethrow;
  } finally {
    client.close();
  }
}
