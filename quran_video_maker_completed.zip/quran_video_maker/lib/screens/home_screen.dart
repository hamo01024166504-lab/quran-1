import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:video_player/video_player.dart';
import '../core/audio.dart';
import '../core/quran.dart';
import '../core/store.dart';
import '../core/net.dart';
import '../core/video_export.dart';

enum Reveal { highlight, progressive, ayah }

const palette = <String, Color>{
  'أبيض': Color(0xFFFFFFFF),
  'ذهبي': Color(0xFFF5C542),
  'كريمي': Color(0xFFFFF1CC),
  'أخضر فاتح': Color(0xFFA8F0C6),
  'أزرق سماوي': Color(0xFF9AD8FF),
};
const gold = Color(0xFFF5C542);
const sizes = <String, double>{'صغير': 30, 'متوسط': 38, 'كبير': 48, 'كبير جداً': 60};

String _digits(int n) {
  const d = '٠١٢٣٤٥٦٧٨٩';
  return n.toString().split('').map((c) => d[int.parse(c)]).join();
}

class HomeScreen extends StatefulWidget {
  const HomeScreen(this.store, {super.key});
  final Store store;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final repo = QuranRepo(widget.store);
  late final List<Chapter> chapters = repo.chapters();
  late Chapter chapter = chapters.first;
  int from = 1;
  late int to = chapter.verses;
  int reciterId = 7;

  List<String> fonts = [];
  String? font;
  double size = 48;
  Color color = Colors.white;
  bool allahGold = true;
  bool glow = true;
  bool showEn = true;
  Reveal mode = Reveal.highlight;

  List<Ayah> ayat = [];
  AudioData? audio;
  int startMs = 0, endMs = 0;
  bool loading = false;
  final curMs = ValueNotifier<int>(0);
  final player = AudioPlayer();
  StreamSubscription<Duration>? _sub;

  List<File> bgFiles = [];
  VideoPlayerController? bg;
  int bgIndex = -1;
  File? customAudio;
  final Set<String> selectedScenePaths = {};
  bool mixScenes = false;
  VideoPreset exportPreset = videoPresets.first;
  bool exporting = false;
  double exportProgress = 0;
  String exportStatus = '';

  @override
  void initState() {
    super.initState();
    _loadFonts();
    bgFiles = widget.store.backgrounds();
    if (bgFiles.isNotEmpty) _setBg(0);
    _sel();
    _sub = player
        .createPositionStream(
            minPeriod: const Duration(milliseconds: 30),
            maxPeriod: const Duration(milliseconds: 60))
        .listen((d) {
      if (audio == null) return;
      final ms = d.inMilliseconds;
      if (ms >= endMs && player.playing) player.pause();
      curMs.value = ms.clamp(startMs, endMs).toInt();
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    player.dispose();
    bg?.dispose();
    super.dispose();
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _loadFonts({String? select}) async {
    final f = await widget.store.loadFonts();
    if (!mounted) return;
    setState(() {
      fonts = f;
      font = select ??
          font ??
          f.firstWhere((x) => x.contains('AmiriQuran'),
              orElse: () => f.isEmpty ? '' : f.first);
      if (font == '') font = null;
    });
  }

  Future<void> _addFont() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      final path = r?.files.single.path;
      if (path == null) return;
      final low = path.toLowerCase();
      if (!low.endsWith('.ttf') && !low.endsWith('.otf')) {
        _snack('اختار ملف خط بصيغة TTF أو OTF');
        return;
      }
      final fileName = path.split('/').last;
      await File(path).copy(widget.store.file('fonts/$fileName').path);
      await _loadFonts(select: fileName.replaceAll(RegExp(r'\.(ttf|otf)$', caseSensitive: false), ''));
    } catch (e) {
      _snack('تعذر إضافة الخط: $e');
    }
  }

  bool _isImage(File f) => RegExp(r'\.(png|jpe?g|webp|bmp)$', caseSensitive: false).hasMatch(f.path);

  Future<void> _setBg(int i) async {
    if (i < 0) {
      final old = bg;
      if (mounted) setState(() { bgIndex = -1; bg = null; });
      old?.dispose();
      return;
    }
    if (i >= bgFiles.length) return;
    final file = bgFiles[i];
    final old = bg;
    if (_isImage(file)) {
      if (mounted) setState(() { bgIndex = i; bg = null; });
      old?.dispose();
      return;
    }
    final c = VideoPlayerController.file(file,
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true));
    try {
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      await c.play();
      if (!mounted) { await c.dispose(); return; }
      setState(() { bgIndex = i; bg = c; });
      old?.dispose();
    } catch (e) {
      await c.dispose();
      if (mounted) _snack('تعذر تشغيل الخلفية: $e');
    }
  }

  Future<void> _addBackground() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.any);
      final path = r?.files.single.path;
      if (path == null) return;
      final ext = path.split('.').last.toLowerCase();
      if (!['mp4', 'mov', 'm4v', 'png', 'jpg', 'jpeg', 'webp', 'bmp'].contains(ext)) {
        _snack('اختار صورة أو فيديو بصيغة PNG/JPG/WEBP/MP4/MOV');
        return;
      }
      final target = widget.store.file('bg/import_${DateTime.now().millisecondsSinceEpoch}.$ext');
      await File(path).copy(target.path);
      selectedScenePaths.add(target.path);
      bgFiles = widget.store.backgrounds();
      final index = bgFiles.indexWhere((f) => f.path == target.path);
      if (index >= 0) await _setBg(index);
    } catch (e) {
      _snack('تعذر إضافة الخلفية: $e');
    }
  }

  Future<void> _shuffleBackground() async {
    if (bgFiles.isEmpty) {
      _snack('أضف خلفية من الهاتف أو ابحث عن مقاطع Pexels أولًا.');
      return;
    }
    final candidates = List<int>.generate(bgFiles.length, (i) => i).where((i) => i != bgIndex).toList();
    final next = (candidates.isEmpty ? List<int>.generate(bgFiles.length, (i) => i) : candidates)
      ..shuffle(Random());
    await _setBg(next.first);
  }

  Future<void> _searchPexels() async {
    var key = widget.store.pexelsKey;
    if (key.isEmpty) {
      final ctl = TextEditingController();
      final entered = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('مفتاح Pexels API'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('احصل على مفتاح مجاني من pexels.com/api. يُحفظ المفتاح على هذا الجهاز.'),
          TextField(controller: ctl, decoration: const InputDecoration(labelText: 'API key')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text.trim()), child: const Text('حفظ'))],
      ));
      ctl.dispose();
      if (entered == null || entered.isEmpty) return;
      key = entered;
      widget.store.pexelsKey = key;
    }
    final queryCtl = TextEditingController(text: 'ocean waves');
    final query = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('البحث عن خلفيات Pexels'),
      content: TextField(controller: queryCtl, decoration: const InputDecoration(labelText: 'مثال: ocean, stars, mosque')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () => Navigator.pop(ctx, queryCtl.text.trim()), child: const Text('بحث'))],
    ));
    queryCtl.dispose();
    if (query == null || query.isEmpty) return;
    setState(() => loading = true);
    try {
      final result = await getJson('https://api.pexels.com/videos/search?query=${Uri.encodeQueryComponent(query)}&orientation=portrait&per_page=12', headers: {'Authorization': key});
      final videos = (result['videos'] as List? ?? const []).whereType<Map>().map((x) => Map<String, dynamic>.from(x)).toList();
      if (!mounted) return;
      if (videos.isEmpty) { _snack('لم يتم العثور على فيديوهات. جرّب كلمة بحث أخرى.'); return; }
      await showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (ctx) => SafeArea(
        child: SizedBox(height: MediaQuery.of(ctx).size.height * .72, child: Column(children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('اختار مقطعًا لتنزيله', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
          Expanded(child: ListView.builder(itemCount: videos.length, itemBuilder: (_, i) {
            final v = videos[i];
            final files = (v['video_files'] as List? ?? const []).whereType<Map>().map((x) => Map<String, dynamic>.from(x)).where((x) => x['file_type'] == 'video/mp4' && x['link'] != null).toList();
            files.sort((a, b) => (((a['width'] as num?) ?? 720) - 720).abs().compareTo((((b['width'] as num?) ?? 720) - 720).abs()));
            if (files.isEmpty) return const SizedBox.shrink();
            final file = files.first;
            return ListTile(leading: const Icon(Icons.video_library), title: Text('مقطع ${v['id']}'), subtitle: Text('${file['width'] ?? '?'} × ${file['height'] ?? '?'}'), trailing: const Icon(Icons.download), onTap: () async {
              Navigator.pop(ctx);
              setState(() => loading = true);
              try {
                final target = widget.store.file('bg/pexels_${v['id']}.mp4');
                await download('${file['link']}', target);
                selectedScenePaths.add(target.path);
                bgFiles = widget.store.backgrounds();
                final index = bgFiles.indexWhere((f) => f.path == target.path);
                if (index >= 0) await _setBg(index);
                if (mounted) _snack('تم تنزيل الخلفية واختيارها.');
              } catch (e) { if (mounted) _snack('تعذر تنزيل مقطع Pexels: $e'); }
              finally { if (mounted) setState(() => loading = false); }
            });
          }))
        ])),
      ));
    } catch (e) {
      if (mounted) _snack('فشل البحث في Pexels. تحقق من المفتاح والإنترنت: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _addAudioFile() async {
    try {
      final r = await FilePicker.platform.pickFiles(type: FileType.audio);
      final path = r?.files.single.path;
      if (path == null) return;
      final ext = path.split('.').last.toLowerCase();
      if (!['mp3', 'm4a', 'aac', 'wav', 'ogg', 'flac'].contains(ext)) {
        _snack('صيغة الصوت غير مدعومة. جرّب MP3 أو M4A أو WAV.');
        return;
      }
      final target = widget.store.file('audio/custom_${DateTime.now().millisecondsSinceEpoch}.$ext');
      await File(path).copy(target.path);
      customAudio = target;
      audio = null;
      await player.stop();
      if (mounted) setState(() {});
      _snack('تم اختيار الملف الصوتي. سيتم تقدير توقيت الآيات بالتساوي؛ الأفضل استخدام تلاوة مطابقة للآيات المختارة.');
    } catch (e) {
      _snack('تعذر إضافة الملف الصوتي: $e');
    }
  }

  Future<void> _exportVideo() async {
    if (exporting || loading) return;
    if (ayat.isEmpty) { _snack('انتظر تحميل الآيات أولًا.'); return; }
    if (mixScenes && selectedScenePaths.length < 2) { _snack('اختار مقطعين أو أكثر لخلط المشاهد عشوائيًا.'); return; }
    if (audio == null) await _prepare();
    try { await player.pause(); } catch (_) {}
    final a = audio;
    if (a == null) { _snack('لم يتم تحميل التلاوة. لا يمكن تصدير فيديو بلا صوت.'); return; }
    if (mixScenes && endMs - startMs < 4000) { _snack('خلط المشاهد يحتاج تلاوة مدتها 4 ثوانٍ على الأقل.'); return; }
    setState(() { exporting = true; exportProgress = 0; exportStatus = 'بدء التصدير…'; });
    try {
      final bgFile = bgIndex >= 0 && bgIndex < bgFiles.length ? bgFiles[bgIndex] : null;
      await VideoExportService.export(
        store: widget.store, audio: a, ayat: ayat, fromVerse: from, toVerse: to,
        startMs: startMs, endMs: endMs, background: bgFile,
        sceneBackgrounds: bgFiles.where((f) => selectedScenePaths.contains(f.path)).toList(),
        mixScenes: mixScenes, preset: exportPreset,
        fontName: font ?? 'Amiri', fontSize: size, textArgb: color.value,
        allahGold: allahGold, showEnglish: showEn, glow: glow,
        onProgress: (v) { if (mounted) setState(() => exportProgress = v.clamp(0, 1).toDouble()); },
        onStatus: (v) { if (mounted) setState(() => exportStatus = v); },
      );
      if (mounted) _snack('تم حفظ الفيديو في المعرض داخل ألبوم Quran Video Maker.');
    } catch (e) {
      if (mounted) _snack('تعذر تصدير الفيديو: $e');
    } finally {
      if (mounted) setState(() { exporting = false; exportProgress = 0; exportStatus = ''; });
    }
  }

  Future<void> _cancelExport() async {
    try { await VideoExportService.cancel(); } catch (_) {}
    if (mounted) _snack('تم طلب إيقاف التصدير.');
  }

  /// يحدّث نص الآيات المختارة ويلغي الصوت المحمّل.
  Future<void> _sel() async {
    try { await player.pause(); } catch (_) {}
    audio = null;
    curMs.value = 0;
    if (mounted) setState(() { loading = true; ayat = []; });
    final selectedChapter = chapter.id;
    try {
      final loaded = await repo.ensureAyat(selectedChapter);
      if (!mounted || chapter.id != selectedChapter) return;
      setState(() => ayat = loaded.where((a) => a.n >= from && a.n <= to).toList());
    } catch (e) {
      if (mounted) _snack('تعذر تحميل آيات السورة. افحص الإنترنت ثم أعد اختيار السورة: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _prepare() async {
    if (mounted) setState(() => loading = true);
    try {
      if (customAudio != null) {
        await player.setFilePath(customAudio!.path);
        final duration = player.duration ?? await player.durationStream.firstWhere((d) => d != null).timeout(const Duration(seconds: 10), onTimeout: () => null);
        if (duration == null || duration.inMilliseconds <= 0) throw Exception('تعذر قراءة مدة الملف الصوتي.');
        startMs = 0;
        endMs = duration.inMilliseconds;
        final count = max(1, ayat.length);
        final span = endMs / count;
        final approximate = <Timing>[];
        for (var i = 0; i < ayat.length; i++) {
          approximate.add(Timing(ayat[i].n, (span * i).round(), (span * (i + 1)).round(), const []));
        }
        audio = AudioData(customAudio!, approximate);
        await player.seek(Duration.zero);
        curMs.value = 0;
      } else {
        final a = await AudioService.ensure(widget.store, reciterId, chapter.id);
        final t0 = a.timings.firstWhere((t) => t.verse == from);
        final t1 = a.timings.firstWhere((t) => t.verse == to);
        audio = a;
        startMs = t0.from;
        endMs = t1.to;
        await player.setFilePath(a.mp3.path);
        await player.seek(Duration(milliseconds: startMs));
        curMs.value = startMs;
      }
    } catch (e) {
      audio = null;
      _snack('تعذر تجهيز التلاوة: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _toggle() async {
    if (player.playing) {
      await player.pause();
      return;
    }
    if (audio == null) await _prepare();
    if (audio == null) return;
    if (curMs.value >= endMs - 50) {
      await player.seek(Duration(milliseconds: startMs));
    }
    player.play();
  }

  // ---------- العرض ----------

  Widget _tile(Word w, {required double alpha, bool active = false}) {
    final c = (w.isAllah ? (allahGold ? gold : Colors.white) : color).withOpacity(alpha);
    final shadows = glow
        ? [
            Shadow(color: c.withOpacity(active ? .95 : .6), blurRadius: active ? 26 : 14),
            Shadow(color: c.withOpacity(.35), blurRadius: 40),
          ]
        : null;
    return AnimatedScale(
      scale: active ? 1.08 : 1,
      duration: const Duration(milliseconds: 120),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(w.ar,
            style: TextStyle(
                fontFamily: font, fontSize: size, height: 1.6, color: c, shadows: shadows)),
      ]),
    );
  }

  Widget _caption(int ms) {
    if (ayat.isEmpty) return const SizedBox();
    var a = ayat.first;
    var activePos = 0;
    final idle = audio == null;
    if (!idle) {
      final ts = audio!.timings.where((t) => t.verse >= from && t.verse <= to);
      final t = ts.lastWhere((x) => x.from <= ms, orElse: () => ts.first);
      a = ayat.firstWhere((x) => x.n == t.verse, orElse: () => ayat.first);
      var segs = t.segs;
      if (segs.isEmpty) {
        final n = a.words.length;
        final span = (t.to - t.from) / max(1, n);
        segs = [for (var i = 0; i < n; i++) [i + 1, (t.from + span * i).round(), (t.from + span * (i + 1)).round()]];
      }
      for (final s in segs) {
        if (ms >= s[1]) activePos = s[0];
      }
    }

    List<Widget> words() {
      final out = <Widget>[];
      for (final w in a.words) {
        if (idle || mode == Reveal.ayah) {
          out.add(_tile(w, alpha: 1));
        } else if (mode == Reveal.progressive) {
          if (w.pos <= activePos) out.add(_tile(w, alpha: 1, active: w.pos == activePos));
        } else {
          out.add(_tile(w,
              alpha: w.pos <= activePos ? 1 : .45, active: w.pos == activePos));
        }
      }
      if (idle || mode == Reveal.ayah || activePos >= a.words.length) {
        out.add(Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text('﴿${_digits(a.n)}﴾',
              style: TextStyle(fontSize: size * .7, color: gold, fontFamily: font)),
        ));
      }
      return out;
    }

    final wrap = Wrap(
      textDirection: TextDirection.rtl,
      alignment: WrapAlignment.center,
      crossAxisAlignment: WrapCrossAlignment.start,
      spacing: 12,
      runSpacing: 14,
      children: words(),
    );

    final caption = Column(mainAxisSize: MainAxisSize.min, children: [
      mode == Reveal.ayah && !idle
          ? AnimatedSwitcher(duration: const Duration(milliseconds: 350), child: KeyedSubtree(key: ValueKey(a.n), child: wrap))
          : wrap,
      if (showEn && a.english.trim().isNotEmpty) ...[
        const SizedBox(height: 10),
        Text(a.english, textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white.withOpacity(.95), fontSize: max(12, size * .30), height: 1.3,
            shadows: const [Shadow(color: Colors.black, blurRadius: 5)])),
      ],
    ]);
    return LayoutBuilder(
      builder: (_, cons) => FittedBox(fit: BoxFit.scaleDown, child: SizedBox(width: cons.maxWidth, child: caption)),
    );
  }

  Widget _preview() {
    final v = bg;
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(fit: StackFit.expand, children: [
        Container(color: const Color(0xFF0B1020)),
        if (bgIndex >= 0 && bgIndex < bgFiles.length && _isImage(bgFiles[bgIndex]))
          Image.file(bgFiles[bgIndex], fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: Colors.black)),
        if (v != null && v.value.isInitialized)
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
                width: v.value.size.width,
                height: v.value.size.height,
                child: VideoPlayer(v)),
          ),
        Container(color: Colors.black.withOpacity(.38)),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Center(
            child: ValueListenableBuilder<int>(
                valueListenable: curMs, builder: (_, ms, __) => _caption(ms)),
          ),
        ),
      ]),
    );
  }

  Widget _section(String t, Widget child) => Padding(
        padding: const EdgeInsets.only(top: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          child,
        ]),
      );

  List<DropdownMenuItem<int>> _ayahItems() => List.generate(chapter.verses,
      (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}')));

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(title: const Text('صانع فيديوهات القرآن')),
      body: Column(children: [
        SizedBox(
            height: h * .44,
            child: Center(child: AspectRatio(aspectRatio: 9 / 16, child: _preview()))),
        StreamBuilder<bool>(
          stream: player.playingStream,
          builder: (_, s) => IconButton.filled(
            iconSize: 34,
            onPressed: loading ? null : _toggle,
            icon: loading
                ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
                : Icon((s.data ?? false) ? Icons.pause : Icons.play_arrow),
          ),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), children: [
            _section(
                'السورة',
                DropdownButton<int>(
                  isExpanded: true,
                  value: chapter.id,
                  items: [
                    for (final c in chapters)
                      DropdownMenuItem(value: c.id, child: Text('${c.id}. ${c.ar}  (${c.en})'))
                  ],
                  onChanged: (v) {
                    chapter = chapters.firstWhere((c) => c.id == v);
                    from = 1;
                    to = chapter.verses;
                    _sel();
                  },
                )),
            _section(
                'الآيات',
                Row(children: [
                  const Text('من '),
                  Expanded(
                      child: DropdownButton<int>(
                          isExpanded: true,
                          value: from,
                          items: _ayahItems(),
                          onChanged: (v) {
                            from = v!;
                            if (to < from) to = from;
                            _sel();
                          })),
                  const SizedBox(width: 16),
                  const Text('إلى '),
                  Expanded(
                      child: DropdownButton<int>(
                          isExpanded: true,
                          value: to,
                          items: _ayahItems(),
                          onChanged: (v) {
                            to = v!;
                            if (from > to) from = to;
                            _sel();
                          })),
                ])),
            _section(
                'القارئ',
                DropdownButton<int>(
                  isExpanded: true,
                  value: reciterId,
                  items: [for (final r in reciters) DropdownMenuItem(value: r.id, child: Text(r.name))],
                  onChanged: (v) {
                    reciterId = v!;
                    _sel();
                  },
                )),
            _section('ملف صوتي من الهاتف (اختياري)', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (customAudio != null) Text('الصوت الحالي: ${customAudio!.uri.pathSegments.last}', maxLines: 2, overflow: TextOverflow.ellipsis),
              Wrap(spacing: 8, children: [
                OutlinedButton.icon(onPressed: loading ? null : _addAudioFile, icon: const Icon(Icons.audio_file), label: const Text('اختيار ملف صوتي')),
                if (customAudio != null) OutlinedButton.icon(onPressed: () { setState(() { customAudio = null; audio = null; }); }, icon: const Icon(Icons.close), label: const Text('استخدام القارئ')),
              ]),
              const Text('عند استخدام ملف خاص، مزامنة الآيات تقديرية وليست توقيتًا موثوقًا من مصدر التلاوة.', style: TextStyle(fontSize: 12)),
            ])),
            _section(
                'الخط',
                Row(children: [
                  Expanded(
                      child: DropdownButton<String>(
                    isExpanded: true,
                    value: fonts.contains(font) ? font : null,
                    hint: const Text('لا توجد خطوط'),
                    items: [for (final f in fonts) DropdownMenuItem(value: f, child: Text(f))],
                    onChanged: (v) => setState(() => font = v),
                  )),
                  IconButton(onPressed: _addFont, icon: const Icon(Icons.add), tooltip: 'إضافة خط'),
                ])),
            _section(
                'حجم الخط',
                Wrap(spacing: 8, children: [
                  for (final e in sizes.entries)
                    ChoiceChip(
                        label: Text(e.key),
                        selected: size == e.value,
                        onSelected: (_) => setState(() => size = e.value)),
                ])),
            _section(
                'لون النص',
                Wrap(spacing: 10, children: [
                  for (final e in palette.entries)
                    GestureDetector(
                      onTap: () => setState(() => color = e.value),
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: e.value,
                          shape: BoxShape.circle,
                          border: Border.all(
                              color: color == e.value ? Colors.tealAccent : Colors.white24,
                              width: color == e.value ? 3 : 1),
                        ),
                      ),
                    ),
                ])),
            _section(
                'لون لفظ الجلالة',
                SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: false, label: Text('أبيض')),
                    ButtonSegment(value: true, label: Text('ذهبي')),
                  ],
                  selected: {allahGold},
                  onSelectionChanged: (s) => setState(() => allahGold = s.first),
                )),
            SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('توهج النص'),
                value: glow,
                onChanged: (v) => setState(() => glow = v)),
            SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('عرض الترجمة الإنجليزية أسفل الآية'),
                value: showEn,
                onChanged: (v) => setState(() => showEn = v)),
            _section(
                'طريقة ظهور النص',
                SegmentedButton<Reveal>(
                  segments: const [
                    ButtonSegment(value: Reveal.highlight, label: Text('تلوين')),
                    ButtonSegment(value: Reveal.progressive, label: Text('تدريجي')),
                    ButtonSegment(value: Reveal.ayah, label: Text('آية كاملة')),
                  ],
                  selected: {mode},
                  onSelectionChanged: (s) => setState(() => mode = s.first),
                )),
            _section('الخلفية', Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 8, runSpacing: 8, children: [
                ChoiceChip(label: const Text('بدون'), selected: bgIndex < 0, onSelected: (_) => _setBg(-1)),
                for (var i = 0; i < bgFiles.length; i++)
                  ChoiceChip(label: Text('خلفية ${i + 1}'), selected: bgIndex == i, onSelected: (_) => _setBg(i)),
              ]),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                OutlinedButton.icon(onPressed: loading ? null : _addBackground, icon: const Icon(Icons.add_photo_alternate), label: const Text('إضافة من الهاتف')),
                OutlinedButton.icon(onPressed: loading ? null : _searchPexels, icon: const Icon(Icons.search), label: const Text('بحث Pexels')),
                OutlinedButton.icon(onPressed: loading ? null : _shuffleBackground, icon: const Icon(Icons.shuffle), label: const Text('عشوائي')),
              ]),
            ])),
            if (bgFiles.isNotEmpty) ...[
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('خلط عدة مشاهد عشوائيًا أثناء التصدير'),
                subtitle: const Text('حدد مقطعين أو أكثر. يتغير ترتيب المشاهد في كل تصدير وتُقص المقاطع حسب مدة التلاوة.'),
                value: mixScenes,
                onChanged: exporting ? null : (v) => setState(() => mixScenes = v),
              ),
              if (mixScenes)
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (var i = 0; i < bgFiles.length; i++)
                    FilterChip(
                      label: Text('مقطع ${i + 1}'),
                      selected: selectedScenePaths.contains(bgFiles[i].path),
                      onSelected: (v) => setState(() {
                        if (v) { selectedScenePaths.add(bgFiles[i].path); } else { selectedScenePaths.remove(bgFiles[i].path); }
                      }),
                    ),
                ]),
            ],
            _section('مقاس وجودة الفيديو', DropdownButton<VideoPreset>(
              isExpanded: true, value: exportPreset,
              items: [for (final p in videoPresets) DropdownMenuItem(value: p, child: Text(p.label, overflow: TextOverflow.ellipsis))],
              onChanged: exporting ? null : (v) { if (v != null) setState(() => exportPreset = v); },
            )),
            const SizedBox(height: 18),
            if (exporting) ...[
              Text(exportStatus),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: exportProgress == 0 ? null : exportProgress, minHeight: 8),
              Align(alignment: Alignment.centerLeft, child: Text('${(exportProgress * 100).round()}%')),
              OutlinedButton.icon(onPressed: _cancelExport, icon: const Icon(Icons.stop_circle), label: const Text('إيقاف التصدير')),
            ],
            FilledButton.icon(
              onPressed: (loading || exporting) ? null : _exportVideo,
              icon: const Icon(Icons.movie_creation),
              label: Text(exporting ? 'جاري تصدير الفيديو…' : 'إنشاء الفيديو وحفظه MP4'),
            ),
            const SizedBox(height: 12),
          ]),
        ),
      ]),
    );
  }
}
