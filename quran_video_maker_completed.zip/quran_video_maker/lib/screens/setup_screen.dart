import 'package:flutter/material.dart';
import '../core/setup.dart';
import '../core/store.dart';
import 'home_screen.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen(this.store, {super.key});
  final Store store;
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  late final SetupController c = SetupController(widget.store);
  bool _navigated = false;

  @override
  void initState() {
    super.initState();
    c.addListener(() {
      if (!mounted) return;
      setState(() {});
      if (c.essentialDone && !c.running) _go();
    });
    c.start();
  }

  void _go() {
    if (_navigated) return;
    _navigated = true;
    widget.store.setupDone = true;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(widget.store)));
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  IconData _icon(String s) => switch (s) {
    'done' => Icons.check_circle,
    'failed' => Icons.error_outline,
    'running' => Icons.downloading,
    _ => Icons.schedule,
  };

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Padding(
      padding: const EdgeInsets.all(20),
      child: ListView(children: [
        const SizedBox(height: 16),
        const Text('تجهيز صانع فيديوهات القرآن', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('ننزّل قائمة السور والخطوط الاختيارية فقط. نص السورة والصوت يتم تحميلهما عند الحاجة لتقليل استهلاك البيانات والذاكرة.'),
        const SizedBox(height: 18),
        LinearProgressIndicator(value: c.total, minHeight: 8),
        const SizedBox(height: 16),
        for (final j in c.jobs) Card(child: ListTile(
          leading: Icon(_icon(j.status)),
          title: Text(j.label),
          subtitle: j.status == 'running'
              ? LinearProgressIndicator(value: j.progress)
              : (j.error != null ? Text(j.error!, maxLines: 3, overflow: TextOverflow.ellipsis) : null),
        )),
        if (!c.running && !c.essentialDone)
          FilledButton.icon(onPressed: c.start, icon: const Icon(Icons.refresh), label: const Text('إعادة المحاولة')),
        if (!c.running && c.essentialDone)
          FilledButton(onPressed: _go, child: const Text('متابعة')),
      ]),
    )),
  );
}
